#include<stdio.h>

	int main () {
		
	printf("\n");
//    printf("\x1B[31mTexting\033[0m\n");
//    printf("\x1B[32mTexting\033[0m\n");
//    printf("\x1B[33mTexting\033[0m\n");
//    printf("\x1B[34mTexting\033[0m\n");
//    printf("\x1B[35mTexting\033[0m\n");
//    
//    printf("\x1B[36mTexting\033[0m\n");
//    printf("\x1B[36mTexting\033[0m\n");
//    printf("\x1B[36mTexting\033[0m\n");
//    printf("\x1B[37mTexting\033[0m\n");
//    printf("\x1B[93mTexting\033[0m\n");
//    
//    printf("\033[3;42;30mTexting\033[0m\n");
//    printf("\033[3;43;30mTexting\033[0m\n");
//    printf("\033[3;44;30mTexting\033[0m\n");
//    printf("\033[3;104;30mTexting\033[0m\n");
//    printf("\033[3;100;30mTexting\033[0m\n");
//
//    printf("\033[3;47;35mTexting\033[0m\n");
//    printf("\033[2;47;35mTexting\033[0m\n");
//    printf("\033[1;47;35mTexting\033[0m\n");
//    
//	int i=0;
//	while(i++<256)
//	{
//		//for(int j=0;j<100;j++)
//    	printf("%d		\033[%3;43;%dmTexting\033[0m\n",i,i);
//	}
    
    
    printf("\033[2;30;105mTexting\033[0m\n");    //orange
    printf("\033[2;30;103mTexting\033[0m\n");	//Yellow
    printf("\033[2;30;104mTexting\033[0m\n");	//Blue
    printf("\033[2;30;101mTexting\033[0m\n");	//red
    printf("\033[2;30;107mTexting\033[0m\n");	//white
    printf("\033[2;30;102mTexting\033[0m\n");	//green


    
	printf("\t\t");
    printf("\n");	
	return 0;	
	}